package model;

import jakarta.persistence.*;

@Entity
public class User {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(unique = true)
  private String email;

  private String password;
  private String name;
public String getEmail() {
	// TODO Auto-generated method stub
	return null;
}
public CharSequence getPassword() {
	// TODO Auto-generated method stub
	return null;
}
public void setPassword(String encode) {
	// TODO Auto-generated method stub
	
}

  // Getters and Setters
}
