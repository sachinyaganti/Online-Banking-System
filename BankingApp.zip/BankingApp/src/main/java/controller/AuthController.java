	package controller;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.http.*;
	import org.springframework.web.bind.annotation.*;

import model.User;
import repository.UserRepository;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

	import java.util.Optional;

	@RestController
	@RequestMapping("/api/auth")
	@CrossOrigin(origins = "http://localhost:5173")
	public class AuthController {

	  @Autowired
	  private UserRepository userRepository;

	  @PostMapping("/signup")
	  public ResponseEntity<?> signup(@RequestBody User user) {
	    if (userRepository.findByEmail(user.getEmail()).isPresent())
	      return ResponseEntity.badRequest().body("Email already exists");

	    user.setPassword(new BCryptPasswordEncoder().encode(user.getPassword()));
	    return ResponseEntity.ok(userRepository.save(user));
	  }

	  @PostMapping("/login")
	  public ResponseEntity<?> login(@RequestBody User login) {
	    Optional<User> user = userRepository.findByEmail(login.getEmail());
	    if (user.isPresent() && new BCryptPasswordEncoder().matches(login.getPassword(), (String) user.get().getPassword())) {
	      return ResponseEntity.ok(user.get());
	    }
	    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
	  }
	}
